// declarations.d.ts
declare module "@react-native-checkbox/checkbox" {
  import * as React from "react";
  import { ViewProps, StyleProp, ViewStyle } from "react-native";
  const CheckBox: React.ComponentType<{
    value?: boolean;
    onValueChange?: (value: boolean) => void;
    tintColors?: { true?: string; false?: string };
    style?: StyleProp<ViewStyle>;
  }>;
  export default CheckBox;
}
