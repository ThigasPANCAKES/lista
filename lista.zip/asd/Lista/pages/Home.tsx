import React, { useState } from "react";
import { View, FlatList, StyleSheet } from "react-native";
import Title from "./components/Title";
import TextInputBox from "./components/TextInputBox";
import AddButton from "./components/AddButton";
import TaskItem from "./components/TaskItem";

export default function Home() {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState<{ id: string; text: string; done: boolean }[]>([]);

  const addTask = () => {
    if (task.trim().length === 0) return;
    setTasks([...tasks, { id: Date.now().toString(), text: task, done: false }]);
    setTask("");
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  return (
    <View style={styles.container}>
      <Title text="Tarefas" />

      <View style={styles.inputRow}>
        <TextInputBox value={task} onChangeText={setTask} placeholder="Digite uma tarefa" />
        <AddButton onPress={addTask} />
      </View>

      <FlatList
        data={tasks}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TaskItem task={item} onToggle={() => toggleTask(item.id)} />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, marginTop: 40 },
  inputRow: { flexDirection: "row", marginBottom: 20, alignItems: "center" },
});
