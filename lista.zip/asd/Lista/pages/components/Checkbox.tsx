import React from "react";
import { StyleSheet } from "react-native";
import CheckBox from "@react-native-community/checkbox";

type Props = {
  value: boolean;
  onValueChange: (newValue: boolean) => void;
};

export default function Checkbox({ value, onValueChange }: Props) {
  return (
    <CheckBox
      value={value}
      onValueChange={onValueChange}
      tintColors={{ true: "#6c5ce7", false: "#ccc" }}
      style={styles.checkbox}
    />
  );
}

const styles = StyleSheet.create({
  checkbox: {
    marginRight: 10,
  },
});
