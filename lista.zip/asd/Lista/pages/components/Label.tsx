import React from "react";
import { Text, StyleSheet } from "react-native";

type Props = {
  text: string;
  done?: boolean;
};

export default function Label({ text, done }: Props) {
  return <Text style={[styles.text, done && styles.done]}>{text}</Text>;
}

const styles = StyleSheet.create({
  text: {
    marginLeft: 10,
    fontSize: 16,
  },
  done: {
    textDecorationLine: "line-through",
    color: "gray",
  },
});
