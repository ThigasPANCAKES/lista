import React from "react";
import { View, StyleSheet } from "react-native";
import Checkbox from "./Checkbox";
import Label from "./Label";

type Task = { id: string; text: string; done: boolean };

type Props = { task: Task; onToggle: () => void };

export default function TaskItem({ task, onToggle }: Props) {
  return (
    <View style={styles.item}>
      <Checkbox value={task.done} onValueChange={() => onToggle()} />
      <Label text={task.text} done={task.done} />
    </View>
  );
}

const styles = StyleSheet.create({
  item: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
});
